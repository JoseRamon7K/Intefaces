
function borrar() {
    var search=document.getElementById("search");
    search.value=""; 
    console.log(innerWidth);
       
}
function borrar2() {
    var search=document.getElementById("search2");
    search.value=""; 
    console.log(innerWidth);
       
}

function search() {
    var search=document.getElementById("search");
    
}
function search2() {
    var search=document.getElementById("search2");
    
}